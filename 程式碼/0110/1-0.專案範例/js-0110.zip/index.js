const a = 1
a = 2 + 2 + 4 + 7
